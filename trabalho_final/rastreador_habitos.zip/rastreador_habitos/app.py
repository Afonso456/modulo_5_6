from _ import adicionar_utilizador,remover_utilizador,adicionar_habitos,remover_habitos,registar_progresso,listar_habitos
import utils

#TODO mudar o nome do modulo prncipal
def main():
    op = 0
    while op != 7:
        op = utils.menu(['Adicionar utilizadores','Remover utilizador','Adicionar habito','Remover habito','Listar habitos','Registar progresso','Sair'])
        if op == 7:
            break
        if op == 1:
            adicionar_utilizador()
        if op == 2:
            remover_utilizador()
        if op == 3:
            adicionar_habitos()
        if op == 4:
            remover_habitos()
        if op == 5:
            listar_habitos()
        if op == 6:
            registar_progresso()

if __name__ == "__main__":
    main()